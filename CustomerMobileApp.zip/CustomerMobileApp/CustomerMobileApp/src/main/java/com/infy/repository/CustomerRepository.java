package com.infy.repository;

public interface CustomerRepository{
	

}
