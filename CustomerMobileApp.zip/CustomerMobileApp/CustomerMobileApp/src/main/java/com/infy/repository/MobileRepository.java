package com.infy.repository;

public interface MobileRepository{

	
}
